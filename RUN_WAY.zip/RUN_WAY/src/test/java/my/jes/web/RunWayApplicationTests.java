package my.jes.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
