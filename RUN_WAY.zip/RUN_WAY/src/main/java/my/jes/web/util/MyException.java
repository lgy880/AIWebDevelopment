package my.jes.web.util;

public class MyException extends Exception {

	public MyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
