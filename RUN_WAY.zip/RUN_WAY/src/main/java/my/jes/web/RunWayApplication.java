package my.jes.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunWayApplication.class, args);
	}

}
